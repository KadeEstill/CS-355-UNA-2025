#ifndef H_FizzBuzz
#define H_FizzBuzz

class FizzBuzz
{
    public:
        FizzBuzz(); //constructor has no return type
        void Run();
        void SetLimit(int range);
        
    private:
        int limit;
};

#endif