// ---------------------------------------------------------------------------
// Name: Kade Estill
// Course-Section: CS355-01
// Assignment: 1
// Date due: 08/26/2025
// Description: This program implements a game called Fizz Buzz where it
// numbers are listed from 1-100. Except, everytime a number listed is 
// divisible by 3, "Fizz" is printed instead. Everytime a number is divisible
// by 5, it prints "Buzz" instead. Everytime a number is divisible by 3 and 5
// (or in other words divisble by 15) it prints "FizzBuzz".
// ---------------------------------------------------------------------------

#include <iostream>
#include "FizzBuzz.h"

using namespace std;

int main()
{
    const int RANGE_OF_GAME = 100;
    /*I have to create a variable of type FizzBuzz
    * in order to begin runnign
    */
    FizzBuzz playGame;
    playGame.SetLimit(RANGE_OF_GAME);
    playGame.Run();

    return 0;
}