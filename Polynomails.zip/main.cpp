// ---------------------------------------------------------------------------
// Name: Kade Estill
// Course-Section: CS355-section 01
// Assignment: #0.5
// Date due: 08/26/2025
// Description: This assignment takes the solution from one of the projects
// completed in CS 255, and then edits the code to fit the formatting rules
// provided to us by Dr. Ray on canvas
// ---------------------------------------------------------------------------


#include <iostream>
#include "Poly.h"
#include <fstream>

using namespace std;

int main()
{
    ifstream myfile ("poly.txt"); //opens file "poly.txt" for reading

    Poly myPoly; //creates a new variable of Poly type from struct class

    /* Insert function adds new coefficient and exponent pair to the polymonial */
    myPoly.Insert(5, 4);
    myPoly.Insert(3, 3);
    myPoly.Insert(17, 1);

    /* Evaluates polynomial when x = 2 */
    cout << myPoly << endl;
    cout << "Evaluate at x = 2" << endl;
    cout << myPoly.Evaluate(2) << endl; 

    /* Adds new terms */
    myPoly.Insert(6, 8);
    myPoly.Insert(2, 6);

    /* Prints reverse (lowest exponent to highest exponent) */
    myPoly.PrintReverse();

    /* Adds another term */
    myPoly.Insert(5, 0);
    cout << myPoly << endl;

    /* Searches for exponents 6 and 7 */
    cout << myPoly.Search(6) << endl;
    cout << myPoly.Search(7) << endl;

    /* Copies myPoly into copyPoly, and adds new terms*/
    Poly copyPoly;
    copyPoly = myPoly;
    copyPoly.Insert(2, 2);
    copyPoly.Insert(9, 9);
    myPoly.Insert(7, 7);

    /* Prints polynomials and adds them together */
    Poly result;
    cout << myPoly << endl;
    cout << copyPoly << endl;
    cout << "********Adding********" << endl;
    result = myPoly + copyPoly;
    cout << result << endl;
    cout << "****************" << endl;

    /* Subtracts two polynomial */
    cout << "********Subtracting********" << endl;
    result = myPoly - copyPoly;
    cout << result << endl;
    cout << "****************" << endl;

    /* Differentiates first time */
    cout << "****************" << endl;
    cout << copyPoly << endl;
    cout << "Derivation One" << endl;
    copyPoly.Derivative();
    cout << copyPoly << endl;

    /* Differentiates second time */
    cout << "Derivation Two" << endl;
    copyPoly.Derivative();
    cout << copyPoly << endl;

    /* Differentiates third time */
    cout << "Derivation Three" << endl;
    copyPoly.Derivative();
    cout << copyPoly << endl;
    cout << "****************" << endl;

    /* Resets the terms of myPoly and evaluates */
    myPoly.Reset();
    cout << myPoly << endl;
    cout << myPoly.Evaluate(2) << endl;
    cout << copyPoly << endl;

    /* Uncertain what this is doing */
    cout << "********Use >>*******" << endl;
    Poly p3;
    //cin >> p3;
    myfile >> p3;
    cout << p3 << endl;

    myfile.close(); //close file
    return 0;
}
