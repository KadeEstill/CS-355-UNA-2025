#include "Poly.h"

//---------------------------------------------------------------------------
/* The Poly() function is a constructor that initializes the head of a blank
* polynomial. This is done by setting the head node to a nullptr.
* INCOMING DATA: None
* OUTGOING DATA: None
*/
Poly::Poly()
{
    head = nullptr; //initializes the polynomial to be empty
}

//---------------------------------------------------------------------------
/* This Poly() function is copy constructor that constructs a new polynomial 
* that is a copy of another. I believe this is considered a deep copy. So
* essentially it creates an independent duplicate of the blank polynomial.
* INCOMING DATA: Reference to a Poly object
* OUTGOING DATA: None
*/
Poly::Poly(const Poly& other)
{
    head = nullptr; //makes new poly empty
    copyList(other); //creates copy of other poly
}

//---------------------------------------------------------------------------
/* I am slightly confused on overloading operators, so I will explain them to.
* the best of my ability. Overloading the >> operator allows the program to
* read the input in the format of a polynomial. 
* INCOMING DATA: Two references: one to a polynomial and an input stream
* OUTGOING DATA: One passed by reference: the poly is updated
*/
istream& operator>>(istream& is, Poly& p)
{
    p.Reset(); //resets poly to get rid of all terms

    char next;
    string s_coeff;
    string s_exp;
    int i_coeff;
    int i_exp;

    is>>next; 
    if(next != '<')
    {
        cout << "ERROR IN INPUT FORMAT" << endl;
        return is;
    }
    is>>next; 
    while(next != '>')
    {
        s_coeff = "";
        s_exp = "";
        while(next != 'x')
        {
            s_coeff += next;
            is>>next;
        }
        i_coeff = stoi(s_coeff);

        is>>next; 
        is>>next; 
        while(next != '+' && next != '>')
        {
            s_exp += next;
            is>>next;
        }
        i_exp = stoi(s_exp);

        p.Insert(i_coeff, i_exp);

        if(next != '>')
        {
            is>>next; 
        }
    }
    return is;
}

//---------------------------------------------------------------------------
/* Overloading the operator << makes the operator output the polynomial in
* the correct format with coefficients and exponents.
* INCOMING DATA: Two references:
* OUTGOING DATA: None
*/
ostream& operator<<(ostream& os, const Poly& p)
{
    Term* current; //pointer to the current term
    current = p.head; //sets current to head of polynomial
    os << "<"; //just starts the ouput of the polynomial with <

    /* While loop will loop though the polynomial */
    while(current != nullptr)
    {
        cout << current->coeff; //prints coefficient
        if(current->exp != 0)
        {
            cout << "x^" << current->exp; //prints exponent
        }
        if(current->next != nullptr)
        {
            cout << " + "; 
        }
        current = current->next; //moves to next
    }
    os << ">" << endl; //closes polynomial with >
    return os; //returns the stream
}

//---------------------------------------------------------------------------
/* The Reset() function clears all elements of the polynomial. It does this 
* by deleting each node in the linked list.
* INCOMING DATA: None
* OUTGOING DATA: None
*/
void Poly::Reset()
{
    Term* current;
    Term* temp;
    current = head;
    /* This while loop iterates until the end of the polynomial */
    while(current != nullptr)
    {
        temp = current;
        current = current->next;
        delete temp; //deletes each term
    }
    head = nullptr; //sets head back to null
}

//---------------------------------------------------------------------------
/* The Evaluate() function solves the polynomial calculating one
* coefficient and exponent group at a time with the value of x.
* INCOMING DATA: 1 integer, the value of x
* OUTGOING DATA: 1 integer, the result of the polynomial
*/
int Poly::Evaluate(int x)
{
    int val = 0;
    Term* current = head;
    /* For each term it computes with the given value of x */
    while(current != nullptr)
    {
        val = val + ((pow(x, current->exp)) * current->coeff);
        current = current->next;
    }
    return val;
}

//---------------------------------------------------------------------------
/* The operator+() function is an overloading operator that allows the 
* addition of polynomials. This is needed because each term is made up of
* a coefficient and exponent.
* INCOMING DATA: One reference to a new polynomial
* OUTGOING DATA: Returns the new poly from sum
*/
Poly Poly::operator+(const Poly& rhs)const
{
    Term* left;
    Term* right;

    Poly sum;

    left = head; //head of original polynomial
    right = rhs.head; //head of other polynomial

    while(left != nullptr && right != nullptr)
    {
        /* If the exponents match, it will had the terms together */
        if(left->exp == right->exp)
        {
            sum.Insert(left->coeff + right->coeff, left->exp); //inserts term into sum
            left = left->next;
            right = right->next;
        }
        /* If the left exponent is bigger */
        else if(left->exp > right->exp)
        {
            sum.Insert(left->coeff, left->exp);
            left = left->next;
        }
        /* If the right exponent is bigger */
        else if(left->exp < right->exp)
        {
            sum.Insert(right->coeff, right->exp);
            right = right->next;
        }
    }
    /* Will copy the leftover terms into result poly */
    if(left == nullptr && right != nullptr)
    {
        while(right != nullptr)
        {
            sum.Insert(right->coeff, right->exp);
            right = right->next;
        }
    }
    /* Same thing here as above */
    else if(right == nullptr && left != nullptr)
    {
        while(left != nullptr)
        {
            sum.Insert(left->coeff, left->exp);
            left = left->next;
        }
    }
    return sum; //returns the sum of polynomials
}

//---------------------------------------------------------------------------
/* The operator-() function  is an overloading performs subtraction of 
* polynomials.
* INCOMING DATA: One reference to a new polynomial
* OUTGOING DATA: returns the difference of polynomials
*/
Poly Poly::operator-(const Poly& rhs)const
{
    Term* left;
    Term* right;

    Poly diff; //creates poly variable to store the difference of polynomials

    left = head;
    right = rhs.head;

    while(left != nullptr && right != nullptr)
    {
        /* If the exponents match this loop will subtract them */
        if(left->exp == right->exp)
        {
            int x;
            x = left->coeff + (-1*right->coeff);
            if(x != 0)
            {
                diff.Insert(x, left->exp); //inserts term into diff
            }
            left = left->next;
            right = right->next;
        }
        else if(left->exp > right->exp)
        {
            diff.Insert(left->coeff, left->exp);
            left = left->next;
        }
        else if(left->exp < right->exp)
        {
            diff.Insert((-1*right->coeff), right->exp);
            right = right->next;
        }
    }
    /* Will copy the leftover terms into result poly */
    if(left == nullptr && right != nullptr)
    {
        while(right != nullptr)
        {
            diff.Insert((-1*right->coeff), right->exp);
            right = right->next;
        }
    }
    /* Same thing as above */
    else if(right == nullptr && left != nullptr)
    {
        while(left != nullptr)
        {
            diff.Insert(left->coeff, left->exp);
            left = left->next;
        }
    }
    return diff; //returns the difference of polynomials
}

//---------------------------------------------------------------------------
/* The Derivative() function takes the terms of the polynomial and finds
* the derivative of it. This is done by multiplying the coefficient by the 
* exponent, and then reducing the exponent by 1.
* INCOMING DATA: None
* OUTGOING DATA: None
*/
void Poly::Derivative()
{
    Term* current;
    Term* previous;
    current = head;

    if(current!=nullptr)
    {
        /*If the exponent is zero, then it deletes the node, because any coefficient
        * times zero is just zero.
        */
        if(current->exp == 0)
        {
            delete current;
            head = nullptr;
        }
        /*If the next node is nullptr, then there is only one term to evaluate*/
        else if(current->next == nullptr)
        {
            current->coeff = current->coeff * current->exp; //multiply the coefficient by the exponent
            current->exp = current->exp - 1; //then the exponent is reduced by 1
        }
        else //will excecute if there are multiple terms
        {
            /*This section finds the derivative of a term in the polynomial*/
            current->coeff = current->coeff * current->exp; //multiply the coefficient by the exponent
            current->exp = current->exp - 1; //then the exponent is reduced by 1
            previous = current;
            current = current->next;
            while(current != nullptr) //cycles through polynomial and finds derivative of eacg term
            {
                if(current->exp == 0)
                {
                    previous->next = nullptr;
                    delete current;
                    current = nullptr;
                }
                else
                {
                    current->coeff = current->coeff * current->exp;
                    current->exp = current->exp - 1;
                    previous = current;
                    current = current->next;
                }
            }
        }
    }

}

//---------------------------------------------------------------------------
/* The insert() function adds a new term to the polynomial: a coefficient and
* exponent pair.
* INCOMING DATA: Two integers: one coefficient and one exponent
* OUTGOING DATA: None
*/
void Poly::Insert(int c, int e)
{
    Term* newT = new Term;
    newT->coeff = c; //sets coefficient of newT to c 
    newT->exp = e; //sets exponent of newT to e
    newT->next = nullptr; 

    Term* current;
    Term* previous;

    if(head == nullptr)
    {
        head = newT; //if poly is empty, make newT the first term
    }
    else if(head->exp < e) //if the new term's exponent is greater than first terms...
    {
        newT->next = head; //then link newT to the current head
        head = newT; //and make head point to newT
    }
    else //else will traverse the list to find the right position
    {
        current = head;

        while(current != nullptr && current->exp > e)
        {
            previous = current;
            current = current->next; //current will move forward while exp > e
        }

        if(current == nullptr)
        {
            previous->next = newT; //if the end is reach, add newT to the end
        }
        else
        {
            previous->next = newT;
            newT->next = current; //add newT between previous node and current
        }
    }
}

//---------------------------------------------------------------------------
/* The Search() function will iterate through the polynomial until it finds
* a term with the target exponent. For example, if the target exponent is
* 2, then it will iterate to the coefficient whose exponent value is 2.
* INCOMING DATA: One integer: the target exponent to search for
* OUTGOING DATA: 
*/
Term* Poly::Search(int targetExp)
{
    Term* srch; //creates pointer variable to srch
    srch = head;

    while(srch != nullptr) //iterate through polynomial
    {
        if(srch->exp == targetExp)
        {
            return srch; //return the term if it is found
        }
        srch = srch->next; //go to next term
    }
    return nullptr; //return null if the term does not exist
}

//---------------------------------------------------------------------------
/* The PrintReverse() function is simple, it prints the polynomial in the 
* reverse order at which each term initially exists. Starting with exp = 0.
* Calls on recPrintRev() function.
* INCOMING DATA: None
* OUTGOING DATA: None
*/
void Poly::PrintReverse()
{
    Term* current;
    current = head; 
    cout<<"<";
    recPrintRev(current); //calls on recPrintRev to print the reverse of the term
    cout<<">"<<endl;
}

//---------------------------------------------------------------------------
/* The recPrintRev() function uses recursion to print the reverse of the
* term. This is called in the PrintReverse function. 
* INCOMING DATA: One pointer: points to term
* OUTGOING DATA: None
*/
void Poly::recPrintRev(Term* c)
{
    if(c->next != nullptr) //if c is not the end of the list...
    {
        recPrintRev(c->next); //then perform recusion
    }
    cout << c->coeff << "x^" << c->exp << " + "; 
}

//---------------------------------------------------------------------------
/* The operator=() function is an overloading operator that copies the 
* contents of one polynomial to another, then returns the new poly
* INCOMING DATA: One reference to a new poly
* OUTGOING DATA: other is passed by const reference
*/
Poly& Poly::operator=(const Poly& other)
{
    if (this != &other) //avoid self-copy
    {
        copyList(other); //copies polynomial
    }

    return *this;
}

//---------------------------------------------------------------------------
/* The ~Poly() function is a destructor used to reset the polynomial if a
* class object exits the scope.
* INCOMING DATA: None
* OUTGOING DATA: None
*/
Poly::~Poly()
{
    Reset(); //calls reset function
}

//---------------------------------------------------------------------------
/* The copyList() function makes a copy of the polynomial's list. It does 
* this by allocating memory to store the copy.
* INCOMING DATA: One reference to 
* OUTGOING DATA: None
*/
void Poly::copyList(const Poly& otherList)
{
    Term* newT;
    Term* current;
    Term* last;

    if(head != nullptr) //if the list is not empty...
    {
        Reset(); //then resets the polynomial
    }

    if(otherList.head == nullptr) //if the list is not empty...
    {
        head = nullptr; //then reset the polynomial
    }
    /* Else traverses the list. */
    else
    {
        current = otherList.head; //begin at otherList head
        head = new Term; //I think new will allocate memory for a term
        head->coeff = otherList.head->coeff; //copies coefficient over
        head->exp = otherList.head->exp; //copies exponent over
        head->next = nullptr; 

        last = head; 
        current = current->next;

        /* Loop to copy the rest of the nodes */
        while(current != nullptr)
        {
            newT = new Term; //allocates memory
            newT->coeff = current->coeff; //copies coefficient
            newT->exp = current->exp; //copies exponent
            newT->next = nullptr;

            last->next = newT; //adds node to the end

            last = last->next; //moves last forward to the new node
            current = current->next;
        }
    }
}