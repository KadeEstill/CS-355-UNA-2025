#include "FizzBuzz.h"
#include <iostream>

using namespace std;
/* For this assignment, I only used the functions required in the assignment
*  description. I just could not think of any other function that might be
*  useful to have.
*/

//---------------------------------------------------------------------------
/* FizzBuzz() is the constructor for the program. This initializes the limit
* to 100 for usage during the game.
* INCOMING DATA: None
* OUTGOING DATA: None
*/
FizzBuzz::FizzBuzz()
{
    limit = 100; //for this assignment, the limit needs to be initialized to 100
}

//---------------------------------------------------------------------------
/* The Run() function actually excecutes the game. This increments i from
* 1 to 100 and changes numbers divisible by 3 to "Fizz", numbers divisible
* by 5 to "Buzz", and numbers divisible by both to "FizzBuzz".
* INCOMING DATA: None
* OUTGOING DATA: None
*/
void FizzBuzz::Run()
{
    /*For loop to count from 1-100*/
    for(int i = 1; i <= limit; i++)
    {
        if(i % 15 == 0) //if number is divisible by 3 and 5
        {
            cout << "FizzBuzz" << endl; //print FizzBuzz
        }
        else if(i % 3 == 0) //if number is divisble by 3
        {
            cout << "Fizz" << endl; //print Fizz
        }
        else if(i % 5 == 0) //if number is divisible by 5
        {
            cout << "Buzz" << endl; //print Buzz
        }
        else 
        {
            cout << i << endl; //just prints number
        }
    }
}

//---------------------------------------------------------------------------
/* The SetLimit() function, in the case of my program, set the number that
* the game plays through, which is 100. 
* INCOMING DATA: One integer: the number from main (100)
* OUTGOING DATA: None
*/
void FizzBuzz::SetLimit(int range)
{
    limit = range;    //will set the limit to 100 in this case (from main)
}


