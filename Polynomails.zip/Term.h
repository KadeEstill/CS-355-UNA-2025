#ifndef H_Term //if H_Term isnt defined...
#define H_Term //then define H_Term

#include <iomanip>
using namespace std;

struct Term
{
    /* Parts of the polynomial */
    int coeff; //coefficient
    int exp; //exponent
    Term* next; //pointer to another term
};
#endif // H_Term
